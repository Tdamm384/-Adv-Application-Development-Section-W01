


#initalizing coin values 
coin_values = {
    'penny': 0.01,
    'pennies': 0.01,
    'nickel': 0.05,
    'nickels': 0.05,
    'dime': 0.10,
    'dimes': 0.10,
    'quarter': 0.25,
    'quarters': 0.25
}


#splitting user input
def split_input(user_input):
  words = user_input.strip().lower().split()
  if len(words) < 2:
    return None
  coin_quantity = words[0]
  denomination = " ".join(words[1:])
  #checking if quantity is valid
  if not coin_quantity.isdigit():
    return None
  quantity = float(coin_quantity)
  #checking if denomination is valid
  if denomination not in coin_values:
    return None
  #finding value of coin
  return quantity * coin_values[denomination]

#turning the main program into a loop
while True:
  user = input("Enter the quantity and name of the coins: ")
  #accounting for multiple inputs
  Corrected_splitting = user.replace(",", " and")
  parts = [part.strip() for part in Corrected_splitting.split("and") if part.strip()]
  amounts = []
  invalid = False

  for part in parts:
    amount = split_input(part)
    if amount is None:
      print("Invalid Input. Try again.")
      invalid = True
      break  
    amounts.append(amount)
  if not invalid:
    total_amount = sum(amounts)
    print(f"The total amount is: ${total_amount:.2f}")
    break # Exit the loop if input is valid
     #if input is invalid, the loop will continue
  